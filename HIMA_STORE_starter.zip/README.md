# HIMA STORE — Prototype & implementation plan

## What is included
- `public/index.html`: responsive Arabic RTL landing page mockup for HIMA STORE.
- The app cards and downloads are illustrative placeholders. No APK files are hosted and the admin link is not a working login yet.

## Recommended production architecture
- Frontend: Next.js or a similarly maintained framework, Arabic RTL.
- Backend: Node.js/Express or framework API routes.
- Database: PostgreSQL for users, apps, versions, release notes, file hashes, scan status and audit logs.
- File storage: private object storage (S3-compatible) or a private server directory outside the web root.
- Domain and HTTPS: deploy behind a reverse proxy/CDN and enforce HTTPS.

## Admin workflow
1. Sign in with a unique admin account and strong password; enable MFA if available.
2. Upload APK into a private quarantine area (never directly into a public web folder).
3. Validate file size, extension, ZIP/APK structure and expected package metadata. Do not trust the browser-provided MIME type.
4. Run malware scanning (e.g. ClamAV) and optionally submit the SHA-256 hash to a reputation service according to its privacy terms.
5. Review app name, package ID, version, permissions, screenshots, publisher/source and license.
6. Publish only after scan/review passes. Keep rejected uploads inaccessible.
7. Store SHA-256 hash, uploader, timestamps and scan result for auditability.

## Download protection
- Store uploads outside the public web root or in a private bucket.
- Serve downloads only through an application endpoint that checks the app is published and the requested version exists, or issue short-lived signed URLs.
- Use `Content-Disposition: attachment`, a safe generated filename, `X-Content-Type-Options: nosniff`, rate limits and download logging.
- Never allow arbitrary filesystem paths from a request. Use database IDs, not user-supplied paths.
- Keep backups and a deletion/retention policy.

## Security checklist
- HTTPS everywhere; secure, HttpOnly, SameSite cookies.
- Password hashing with Argon2id or bcrypt; MFA for administrators.
- Rate-limit login and upload routes; lockout/backoff after repeated failures.
- CSRF protection for cookie-authenticated state-changing requests.
- Server-side validation, upload size limits, filename randomization, and archive-bomb/resource limits.
- Malware scanning and manual approval before publishing.
- Least-privilege storage permissions; secrets only in environment/secret manager.
- Keep dependencies patched; add audit logs and alerts.
- Back up database and files; test restore procedures.
- Publish only APKs you own or are authorized to distribute. Provide a takedown/contact process and privacy policy.

## Suggested database tables
- `admins(id, email, password_hash, mfa_enabled, created_at, last_login_at)`
- `apps(id, slug, title, description, category, icon_key, status, created_at, updated_at)`
- `app_versions(id, app_id, version_name, version_code, storage_key, sha256, file_size, min_android, scan_status, release_notes, created_at)`
- `audit_logs(id, admin_id, action, object_type, object_id, ip_address, created_at)`

## Deployment phases
1. Approve logo, colors, categories and homepage content.
2. Build public app catalog, app detail pages, search and download counter.
3. Build authenticated admin dashboard and APK upload pipeline.
4. Add quarantine, malware scanning, review/publish workflow and protected downloads.
5. Configure domain, HTTPS, backups, monitoring and privacy/legal pages.
6. Test on Android phones, desktop and low-bandwidth connections before launch.

## Important
This is a visual prototype and implementation plan, not a production-ready secure upload system. Do not use the mockup to accept real uploads until the backend, storage, authentication and scanning pipeline have been implemented and tested.
